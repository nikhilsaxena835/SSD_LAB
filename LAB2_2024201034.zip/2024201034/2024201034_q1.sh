#!/bin/bash
locate -e  $1 | xargs head -4 
