#!/bin/bash
prev=0
curr=1
n=$1

if [ "$n" -eq 1 ]; then
	echo 0
elif [ "$n" -eq 2 ]; then
	echo 1
else

for (( i=1; i<=$n; i++ )) 
do
	temp=$((prev+curr))
	prev=$curr
	curr=$temp
	echo "$prev"
done
fi
