#!/bin/bash
echo $(( $A+$B ))
