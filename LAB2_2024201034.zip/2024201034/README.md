Following assumptions are made for the script
For question 1
1) The argument passed is correct.
2) The file does exists

For question 2 part A
The series is defined as 0 1 1 2 3 5 ... 

For question 2 part B 
It is assumed that the following commands are pre-run on the terminal
export A=10 (or any int)
export B=20 (or any int)
and then the script is executed

