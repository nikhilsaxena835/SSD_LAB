Simply cd to the directory and run the scripts as "./2024201034_q1.sh" or "./2024201034_q2.sh"
