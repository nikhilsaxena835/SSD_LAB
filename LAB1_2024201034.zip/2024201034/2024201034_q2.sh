#!/bin/bash
awk -F ',' '{add=add+$4;}END{print add;}' power_levels.txt
