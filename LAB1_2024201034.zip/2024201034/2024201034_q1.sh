#!/bin/bash
grep -w ".*POST.*404.*" access.log
